"""
Two-pass assembler for the extended mini-ISA.

Turns human-readable assembly text into a list of encoded 32-bit
instruction words, resolving labels for branches/jumps in a first pass.

Supported syntax
=================
    add  rd, rs, rt        sub, and, or, xor, nor, slt   (same form)
    addi rt, rs, imm       andi, ori                     (same form)
    lw   rt, imm(rs)
    sw   rt, imm(rs)
    beq  rs, rt, label
    bne  rs, rt, label
    j    label
    label:
    # comment
"""
from __future__ import annotations
import re

from isa import (encode_r, encode_i, encode_j, REG_NAMES,
                  OPC_ADDI, OPC_ANDI, OPC_ORI, OPC_LW, OPC_SW, OPC_BEQ, OPC_BNE, OPC_J,
                  FUNCT_ADD, FUNCT_SUB, FUNCT_AND, FUNCT_OR, FUNCT_XOR, FUNCT_NOR, FUNCT_SLT)

_R_FUNCT = {"add": FUNCT_ADD, "sub": FUNCT_SUB, "and": FUNCT_AND,
            "or": FUNCT_OR, "xor": FUNCT_XOR, "nor": FUNCT_NOR, "slt": FUNCT_SLT}
_I_OPCODE = {"addi": OPC_ADDI, "andi": OPC_ANDI, "ori": OPC_ORI}
_BRANCH_OPCODE = {"beq": OPC_BEQ, "bne": OPC_BNE}

_MEM_RE = re.compile(r"(-?\d+)\((t\d)\)")


class AssemblerError(Exception):
    pass


def _reg(tok: str) -> int:
    tok = tok.strip()
    if tok not in REG_NAMES:
        raise AssemblerError(f"Unknown register '{tok}'")
    return REG_NAMES[tok]


def assemble(source: str) -> list[int]:
    """Assemble source text into a list of 32-bit instruction words."""
    lines: list[tuple[str | None, str]] = []
    for raw_line in source.splitlines():
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        label = None
        if ":" in line:
            label, _, rest = line.partition(":")
            label, line = label.strip(), rest.strip()
        lines.append((label, line))

    # Pass 1: resolve label -> instruction index
    labels: dict[str, int] = {}
    idx = 0
    for label, line in lines:
        if label:
            if label in labels:
                raise AssemblerError(f"Duplicate label '{label}'")
            labels[label] = idx
        if line:
            idx += 1

    # Pass 2: encode
    words: list[int] = []
    pc = 0
    for _, line in lines:
        if not line:
            continue
        parts = re.split(r"[\s,]+", line)
        mnemonic, args = parts[0].lower(), parts[1:]

        if mnemonic in _R_FUNCT:
            if len(args) != 3:
                raise AssemblerError(f"'{mnemonic}' expects rd, rs, rt: '{line}'")
            rd, rs, rt = _reg(args[0]), _reg(args[1]), _reg(args[2])
            words.append(encode_r(rs, rt, rd, _R_FUNCT[mnemonic]))

        elif mnemonic in _I_OPCODE:
            if len(args) != 3:
                raise AssemblerError(f"'{mnemonic}' expects rt, rs, imm: '{line}'")
            rt, rs, imm = _reg(args[0]), _reg(args[1]), int(args[2], 0)
            words.append(encode_i(_I_OPCODE[mnemonic], rs, rt, imm))

        elif mnemonic in ("lw", "sw"):
            if len(args) != 2:
                raise AssemblerError(f"'{mnemonic}' expects rt, imm(rs): '{line}'")
            rt = _reg(args[0])
            m = _MEM_RE.match(args[1])
            if not m:
                raise AssemblerError(f"Bad memory operand '{args[1]}' in '{line}'")
            imm, rs = int(m.group(1)), _reg(m.group(2))
            opcode = OPC_LW if mnemonic == "lw" else OPC_SW
            words.append(encode_i(opcode, rs, rt, imm))

        elif mnemonic in _BRANCH_OPCODE:
            if len(args) != 3:
                raise AssemblerError(f"'{mnemonic}' expects rs, rt, label: '{line}'")
            rs, rt, target = _reg(args[0]), _reg(args[1]), args[2]
            if target not in labels:
                raise AssemblerError(f"Unknown label '{target}' in '{line}'")
            offset = labels[target] - (pc + 1)  # PC-relative, no branch delay slot
            words.append(encode_i(_BRANCH_OPCODE[mnemonic], rs, rt, offset))

        elif mnemonic == "j":
            if len(args) != 1:
                raise AssemblerError(f"'j' expects a label: '{line}'")
            target = args[0]
            if target not in labels:
                raise AssemblerError(f"Unknown label '{target}' in '{line}'")
            words.append(encode_j(OPC_J, labels[target]))

        else:
            raise AssemblerError(f"Unknown mnemonic '{mnemonic}' in '{line}'")

        pc += 1

    return words


def assemble_file(path: str) -> list[int]:
    with open(path, "r", encoding="utf-8") as f:
        return assemble(f.read())
