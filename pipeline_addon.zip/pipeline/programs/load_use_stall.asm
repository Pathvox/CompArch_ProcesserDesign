# Classic load-use hazard: t1's value isn't ready until lw finishes MEM,
# so the hazard detection unit must stall the pipeline for 1 cycle.
addi t0, t0, 8      # t0 = 8  (byte address 8 -> word index 2)
sw   t0, 0(t0)      # dmem[2] = 8
lw   t1, 0(t0)      # t1 = dmem[2]   -> loaded value not ready next cycle
add  t2, t1, t1     # immediately uses t1: forces a 1-cycle stall
