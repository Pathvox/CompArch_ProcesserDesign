# Back-to-back dependent ALU ops: exercises EX/MEM and MEM/WB forwarding
# without ever needing to stall.
#   t0 = 5
#   t1 = t0 + 10      -> needs t0 forwarded from EX/MEM
#   t2 = t1 + t1      -> needs t1 forwarded from EX/MEM (two cycles later, MEM/WB works too)
#   t3 = t2 - t0
addi t0, t0, 5
addi t1, t0, 10
add  t2, t1, t1
sub  t3, t2, t0
