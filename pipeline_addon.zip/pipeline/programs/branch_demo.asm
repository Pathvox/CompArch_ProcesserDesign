# Taken branch: the instruction fetched into the branch's IF/ID slot
# turns out to be on the wrong path and must be flushed.
addi t0, t0, 3
addi t1, t1, 3
beq  t0, t1, skip   # t0 == t1 -> branch taken, 1-cycle flush
addi t2, t2, 99      # squashed: never committed
skip:
addi t3, t3, 7
