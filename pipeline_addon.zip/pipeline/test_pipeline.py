import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from assembler import assemble, AssemblerError
from pipeline_processor import PipelinedProcessor
import pytest


def run(src: str) -> PipelinedProcessor:
    cpu = PipelinedProcessor(assemble(src))
    cpu.run()
    return cpu


class TestAssembler:
    def test_r_type_roundtrip(self):
        words = assemble("add t2, t0, t1")
        assert len(words) == 1

    def test_unknown_register(self):
        with pytest.raises(AssemblerError):
            assemble("add t9, t0, t1")

    def test_unknown_label(self):
        with pytest.raises(AssemblerError):
            assemble("beq t0, t1, nowhere")

    def test_lw_sw_syntax(self):
        words = assemble("lw t0, 4(t1)\nsw t0, 4(t1)")
        assert len(words) == 2


class TestArithmetic:
    def test_add_sub(self):
        cpu = run("addi t0, t0, 10\naddi t1, t1, 3\nadd t2, t0, t1\nsub t3, t0, t1")
        d = cpu.dump_registers()
        assert d["t2"] == 13
        assert d["t3"] == 7

    def test_logic_ops(self):
        cpu = run("addi t0, t0, 12\naddi t1, t1, 10\nand t2, t0, t1\n"
                   "or t3, t0, t1\nxor t4, t0, t1")
        d = cpu.dump_registers()
        assert d["t2"] == (12 & 10)
        assert d["t3"] == (12 | 10)
        assert d["t4"] == (12 ^ 10)

    def test_slt(self):
        cpu = run("addi t0, t0, 3\naddi t1, t1, 5\nslt t2, t0, t1\nslt t3, t1, t0")
        d = cpu.dump_registers()
        assert d["t2"] == 1
        assert d["t3"] == 0


class TestMemory:
    def test_store_then_load(self):
        cpu = run("addi t0, t0, 8\naddi t1, t1, 77\nsw t1, 0(t0)\nlw t2, 0(t0)")
        assert cpu.dump_registers()["t2"] == 77


class TestHazards:
    def test_forwarding_no_stall_needed(self):
        cpu = run("addi t0, t0, 5\naddi t1, t0, 10\nadd t2, t1, t1")
        d = cpu.dump_registers()
        assert d["t1"] == 15
        assert d["t2"] == 30
        assert cpu.stall_count == 0

    def test_load_use_hazard_stalls_and_forwards_correctly(self):
        cpu = run("addi t0, t0, 8\nsw t0, 0(t0)\nlw t1, 0(t0)\nadd t2, t1, t1")
        d = cpu.dump_registers()
        assert cpu.stall_count == 1
        assert d["t1"] == 8
        assert d["t2"] == 16

    def test_no_hazard_no_stall(self):
        cpu = run("addi t0, t0, 1\naddi t1, t1, 2\naddi t2, t2, 3")
        assert cpu.stall_count == 0


class TestControlFlow:
    def test_taken_branch_squashes_delay_instruction(self):
        cpu = run("addi t0, t0, 3\naddi t1, t1, 3\n"
                   "beq t0, t1, skip\naddi t2, t2, 99\nskip:\naddi t3, t3, 7")
        d = cpu.dump_registers()
        assert d["t2"] == 0          # squashed, must never commit
        assert d["t3"] == 7
        assert cpu.flush_count == 1

    def test_not_taken_branch_falls_through(self):
        cpu = run("addi t0, t0, 3\naddi t1, t1, 4\n"
                   "beq t0, t1, skip\naddi t2, t2, 99\nskip:\naddi t3, t3, 7")
        d = cpu.dump_registers()
        assert d["t2"] == 99         # branch not taken, this must run
        assert d["t3"] == 7
        assert cpu.flush_count == 0

    def test_immediately_preceding_branch_operand_forwards_same_cycle(self):
        # Regression test: the branch depends on the ALU result of the
        # instruction directly before it (still finishing EX when the
        # branch is in ID) — this requires same-cycle EX->ID forwarding.
        cpu = run("addi t0, t0, 3\naddi t1, t1, 3\n"
                   "beq t0, t1, skip\naddi t2, t2, 99\nskip:\naddi t3, t3, 7")
        assert cpu.flush_count == 1
        assert cpu.dump_registers()["t2"] == 0

    def test_jump(self):
        cpu = run("j target\naddi t0, t0, 99\ntarget:\naddi t1, t1, 5")
        d = cpu.dump_registers()
        assert d["t0"] == 0
        assert d["t1"] == 5


class TestPipelineBookkeeping:
    def test_drains_and_traces(self):
        cpu = run("addi t0, t0, 1\naddi t1, t1, 2")
        assert cpu.IF_ID is None and cpu.ID_EX is None
        assert cpu.EX_MEM is None and cpu.MEM_WB is None
        assert len(cpu.trace) == cpu.cycle
