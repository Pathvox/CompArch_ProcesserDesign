"""
Entry point for the 5-stage pipelined processor.

Usage:
    python main_pipeline.py                          # run all bundled demos
    python main_pipeline.py programs/branch_demo.asm  # run one program
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from assembler import assemble_file
from pipeline_processor import PipelinedProcessor

_PROGRAMS_DIR = os.path.join(os.path.dirname(__file__), "programs")
_SEP = "=" * 72


def run_program(path: str) -> None:
    name = os.path.basename(path)
    print(_SEP)
    print(f"  {name}")
    print(_SEP)

    program = assemble_file(path)
    cpu = PipelinedProcessor(program)
    cpu.run()

    cpu.print_diagram()
    print("\nFinal registers:")
    dump = cpu.dump_registers()
    print("  " + "  ".join(f"{k}={v}" for k, v in dump.items()))
    print()


def main() -> None:
    if len(sys.argv) > 1:
        run_program(sys.argv[1])
        return

    for fname in sorted(os.listdir(_PROGRAMS_DIR)):
        if fname.endswith(".asm"):
            run_program(os.path.join(_PROGRAMS_DIR, fname))


if __name__ == "__main__":
    main()
