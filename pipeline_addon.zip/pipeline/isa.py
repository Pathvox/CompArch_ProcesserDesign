"""
Extended mini-ISA for the pipelined processor.

The original single-cycle core (see ../processorr.py) only understood
AND / OR / AND-NOT on a fixed 3-instruction program. This module adds a
real, assemblable instruction set — arithmetic, immediates, memory
access, and control flow — so the pipeline can run arbitrary programs.

Instruction formats (MIPS-style, 32-bit words)
===============================================
R-type:  [31:26] opcode=0x00 | [25:21] rs | [20:16] rt | [15:11] rd | [10:6] shamt | [5:0] funct
I-type:  [31:26] opcode      | [25:21] rs | [20:16] rt | [15:0]  immediate (sign-extended)
J-type:  [31:26] opcode      | [25:0]  target instruction index

Registers are the same 8 general-purpose registers (t0-t7) used
elsewhere in the repo — no register is hardwired to zero.
"""
from __future__ import annotations

# ── Opcodes ──────────────────────────────────────────────────────────
OPC_RTYPE = 0x00
OPC_ADDI  = 0x08
OPC_ANDI  = 0x0C
OPC_ORI   = 0x0D
OPC_LW    = 0x23
OPC_SW    = 0x2B
OPC_BEQ   = 0x04
OPC_BNE   = 0x05
OPC_J     = 0x02

# ── R-type funct codes ──────────────────────────────────────────────
FUNCT_ADD = 0x20
FUNCT_SUB = 0x22
FUNCT_AND = 0x24
FUNCT_OR  = 0x25
FUNCT_XOR = 0x26
FUNCT_NOR = 0x27
FUNCT_SLT = 0x2A

REG_NAMES = {f"t{i}": i for i in range(8)}
REG_NUMS  = {v: k for k, v in REG_NAMES.items()}

MASK32 = 0xFFFF_FFFF

R_MNEMONICS = {FUNCT_ADD: "add", FUNCT_SUB: "sub", FUNCT_AND: "and",
               FUNCT_OR: "or", FUNCT_XOR: "xor", FUNCT_NOR: "nor", FUNCT_SLT: "slt"}
I_MNEMONICS = {OPC_ADDI: "addi", OPC_ANDI: "andi", OPC_ORI: "ori",
               OPC_LW: "lw", OPC_SW: "sw", OPC_BEQ: "beq", OPC_BNE: "bne"}

# Instructions that write a register
WRITES_REG = {"add", "sub", "and", "or", "xor", "nor", "slt", "addi", "andi", "ori", "lw"}
BRANCHES   = {"beq", "bne"}


def _sext16(v: int) -> int:
    v &= 0xFFFF
    return v - 0x1_0000 if v & 0x8000 else v


def encode_r(rs: int, rt: int, rd: int, funct: int, shamt: int = 0) -> int:
    return (((OPC_RTYPE & 0x3F) << 26) | ((rs & 0x1F) << 21) | ((rt & 0x1F) << 16)
            | ((rd & 0x1F) << 11) | ((shamt & 0x1F) << 6) | (funct & 0x3F))


def encode_i(opcode: int, rs: int, rt: int, imm: int) -> int:
    return ((opcode & 0x3F) << 26) | ((rs & 0x1F) << 21) | ((rt & 0x1F) << 16) | (imm & 0xFFFF)


def encode_j(opcode: int, target: int) -> int:
    return ((opcode & 0x3F) << 26) | (target & 0x3FF_FFFF)


class Decoded:
    """Decoded instruction fields, with unused fields left as None."""

    __slots__ = ("opcode", "rs", "rt", "rd", "shamt", "funct", "imm", "addr", "mnemonic", "raw")

    def __init__(self, **kw):
        for k in self.__slots__:
            setattr(self, k, kw.get(k))

    @property
    def writes_reg(self) -> bool:
        return self.mnemonic in WRITES_REG

    @property
    def dest_reg(self) -> int | None:
        if self.mnemonic in R_MNEMONICS.values():
            return self.rd
        if self.mnemonic in ("addi", "andi", "ori", "lw"):
            return self.rt
        return None

    @property
    def is_load(self) -> bool:
        return self.mnemonic == "lw"

    @property
    def is_store(self) -> bool:
        return self.mnemonic == "sw"

    @property
    def is_branch(self) -> bool:
        return self.mnemonic in BRANCHES

    @property
    def is_jump(self) -> bool:
        return self.mnemonic == "j"

    def __repr__(self) -> str:
        return f"<{self.mnemonic}>"


def decode(word: int) -> Decoded:
    opcode = (word >> 26) & 0x3F

    if opcode == OPC_RTYPE:
        rs, rt, rd = (word >> 21) & 0x1F, (word >> 16) & 0x1F, (word >> 11) & 0x1F
        shamt, funct = (word >> 6) & 0x1F, word & 0x3F
        return Decoded(opcode=opcode, rs=rs, rt=rt, rd=rd, shamt=shamt, funct=funct,
                        mnemonic=R_MNEMONICS.get(funct, "?"), raw=word)

    if opcode == OPC_J:
        return Decoded(opcode=opcode, addr=word & 0x3FF_FFFF, mnemonic="j", raw=word)

    rs, rt = (word >> 21) & 0x1F, (word >> 16) & 0x1F
    imm = _sext16(word & 0xFFFF)
    return Decoded(opcode=opcode, rs=rs, rt=rt, imm=imm,
                    mnemonic=I_MNEMONICS.get(opcode, "?"), raw=word)


def alu_compute(mnemonic: str, a: int, b: int) -> int:
    """Shared ALU semantics used by both the interpreter-style checks
    and the pipeline's EX stage."""
    a &= MASK32
    b &= MASK32
    if mnemonic in ("add", "addi"):
        result = a + b
    elif mnemonic == "sub":
        result = a - b
    elif mnemonic in ("and", "andi"):
        result = a & b
    elif mnemonic in ("or", "ori"):
        result = a | b
    elif mnemonic == "xor":
        result = a ^ b
    elif mnemonic == "nor":
        result = ~(a | b)
    elif mnemonic == "slt":
        signed_a = a - (1 << 32) if a & 0x8000_0000 else a
        signed_b = b - (1 << 32) if b & 0x8000_0000 else b
        result = 1 if signed_a < signed_b else 0
    elif mnemonic in ("lw", "sw"):
        result = a + b  # effective address
    else:
        raise ValueError(f"No ALU semantics for '{mnemonic}'")
    return result & MASK32
