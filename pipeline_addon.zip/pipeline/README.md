# 5-Stage Pipelined Processor

Extends the original single-cycle core (`../processorr.py`, limited to a
fixed 3-instruction AND/OR program) into an assemblable mini-ISA running
on a real **IF → ID → EX → MEM → WB** pipeline with hazard handling.

## What's new vs. the single-cycle core

| | Single-cycle (`../processorr.py`) | Pipeline (this folder) |
|---|---|---|
| Instructions | AND, OR, AND-NOT (fixed 3-op program) | ADD, SUB, AND, OR, XOR, NOR, SLT, ADDI, ANDI, ORI, LW, SW, BEQ, BNE, J |
| Programs | Hard-coded in `instruction_memory.py` | Written in a real assembly syntax, turned into machine code by `assembler.py` |
| Execution | One instruction fully completes per cycle | 5 instructions in flight at once, one per stage |
| Hazards | N/A (no overlap) | Hazard detection unit (load-use stalls) + forwarding unit (EX/MEM, MEM/WB, and same-cycle EX→ID bypass for branches) |
| Control flow | N/A | Branches/jumps resolved in ID, with 1-cycle flush penalty on a taken branch |

## Files

- `isa.py` — instruction encoding/decoding and ALU semantics
- `assembler.py` — two-pass assembler (labels, all supported mnemonics)
- `pipeline_processor.py` — the 5-stage pipeline itself
- `main_pipeline.py` — CLI: assemble + run a program, print a cycle diagram
- `programs/` — sample `.asm` programs, each demonstrating a specific hazard
- `test_pipeline.py` — pytest suite (arithmetic, memory, hazards, control flow)

## Running it

```bash
cd pipeline
python main_pipeline.py                          # run all bundled demos
python main_pipeline.py programs/branch_demo.asm  # run one program
python -m pytest test_pipeline.py -v
```

## Example output

`programs/load_use_stall.asm` demonstrates a classic load-use hazard —
`add t2, t1, t1` needs `t1` the cycle after `lw t1, 0(t0)`, before the
loaded value exists anywhere forwardable, so the hazard detection unit
stalls the pipeline for exactly one cycle:

```
instr           C1   C2   C3   C4   C5   C6   C7   C8   C9
-------------------------------------------------------------
[0] addi        IF   ID   EX   MEM  WB
[1] sw               IF   ID   EX   MEM  WB
[2] lw                    IF   ID   EX   MEM  WB
[3] add                        IF   ID   ID   EX   MEM  WB

Total cycles: 9   Stalls: 1   Branch/jump flushes: 0
```

`programs/branch_demo.asm` shows a taken branch: the instruction fetched
into the branch's IF/ID slot is on the wrong path and is squashed before
it can write back (it never appears in the diagram at all).

## Design notes / simplifications

- This is a **behavioral** cycle-accurate model in Python, not
  synthesizable RTL — pipeline latches are plain dicts, evaluated each
  cycle in WB → MEM → EX → ID → IF order so every stage sees the
  previous cycle's state before any latch is overwritten.
- Branches are resolved in ID for a 1-cycle penalty instead of the
  classic 3-cycle penalty from resolving in EX/MEM. This needs an
  extra same-cycle EX→ID forwarding path for the case where a branch
  depends on the ALU result of the instruction immediately before it
  (see the comment above `_forward_id` in `pipeline_processor.py`) —
  a real, if less commonly taught, forwarding technique.
- No register is hardwired to zero (matches the existing 8-register
  `RegisterFile` used elsewhere in the repo).
- Data memory is a flat word-addressable array, separate from the
  multi-level cache simulator in `../memoryhierarchy.py` — that
  module models instruction-stream prefetch timing (SSD → DRAM →
  cache), not byte-addressable load/store storage, so it isn't a
  natural fit for `lw`/`sw`. Worth exploring as a follow-up if you
  want to show the two subsystems talking to each other.

## Suggested next steps

1. **Visualizer**: extend `../visualizer_task4.html` (or add a sibling
   page) to animate this pipeline diagram per cycle instead of the
   single-cycle trace it currently shows.
2. **CI**: add a GitHub Actions workflow running
   `pytest test_processor.py pipeline/test_pipeline.py` on push, and a
   badge in the top-level `README.md`.
3. Fix the case-sensitivity bug in `../test_processor.py`
   (`from alu import ALU` should be `from Alu import ALU`, or rename
   `Alu.py` → `alu.py` for consistency) — it currently only works on
   Windows/macOS's case-insensitive filesystems and will fail on
   Linux CI runners.
