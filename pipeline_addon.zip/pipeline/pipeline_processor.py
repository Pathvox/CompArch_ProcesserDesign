"""
5-stage pipelined processor: IF -> ID -> EX -> MEM -> WB.

Extends the single-cycle core in ../processorr.py with:
  - a real ISA (arithmetic, immediates, loads/stores, branches, jumps)
  - instruction-level pipelining across 5 stages
  - a hazard detection unit that stalls on load-use hazards
  - a forwarding unit that resolves RAW hazards via EX/MEM and MEM/WB
    bypass paths, avoiding stalls whenever forwarding alone suffices
  - early branch resolution in ID (1-cycle branch penalty on a taken
    branch, since the instruction fetched in the branch's IF/ID slot
    must be squashed)

This is a cycle-accurate *behavioral* model (Python dicts standing in
for pipeline latches), not synthesizable RTL — the goal is to make the
hazard/forwarding logic explicit and inspectable, in the same spirit
as the rest of this repo's educational simulators.
"""
from __future__ import annotations
import sys, os

_HERE = os.path.dirname(__file__)
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.dirname(_HERE))  # repo root, for register_file.py
from isa import decode, alu_compute, Decoded, MASK32
from register_file import RegisterFile  # reuse the existing 8-register file


class PipelinedProcessor:

    def __init__(self, program: list[int], data_mem_size: int = 64):
        self.imem = list(program)
        self.regs = RegisterFile()
        self.dmem = [0] * data_mem_size

        self.pc = 0
        self.IF_ID = None   # {'word', 'pc'}
        self.ID_EX = None   # decoded + operand values + control
        self.EX_MEM = None  # + alu_result, store_val
        self.MEM_WB = None  # + write_data

        self.cycle = 0
        self.stall_count = 0
        self.flush_count = 0
        self.trace: list[dict] = []

    def load_registers(self, values: dict[int, int]) -> None:
        self.regs.load(values)

    # ── main loop ────────────────────────────────────────────────
    def run(self, max_cycles: int = 500) -> None:
        while not self._drained():
            self.cycle += 1
            if self.cycle > max_cycles:
                raise RuntimeError("Pipeline did not drain within max_cycles "
                                    "(possible infinite loop in program)")
            self._tick()

    def _drained(self) -> bool:
        return (self.pc >= len(self.imem) and self.IF_ID is None and self.ID_EX is None
                and self.EX_MEM is None and self.MEM_WB is None)

    # ── one clock cycle, stages evaluated WB -> IF so every stage
    #    reads *last* cycle's latches before any of them are updated ──
    def _tick(self) -> None:
        # ---------- WB ----------
        if self.MEM_WB and self.MEM_WB["reg_write"]:
            self.regs.write(self.MEM_WB["write_reg"], self.MEM_WB["write_data"])

        # ---------- MEM ----------
        next_mem_wb = None
        if self.EX_MEM:
            em = self.EX_MEM
            if em["mem_write"]:
                self.dmem[(em["alu_result"] // 4) % len(self.dmem)] = em["store_val"]
            if em["mem_read"]:
                loaded = self.dmem[(em["alu_result"] // 4) % len(self.dmem)]
                write_data = loaded
            else:
                write_data = em["alu_result"]
            next_mem_wb = {**em, "write_data": write_data}

        # ---------- EX ----------
        next_ex_mem = None
        if self.ID_EX:
            ie = self.ID_EX
            val_rs = self._forward(ie["rs"], ie["val_rs"])
            val_rt = self._forward(ie["rt"], ie["val_rt"])
            if ie["mnemonic"] in ("beq", "bne", "j"):
                alu_result = 0  # branches/jumps are resolved in ID; nothing for EX to do
            else:
                if ie["mnemonic"] in ("addi", "andi", "ori", "lw", "sw"):
                    alu_b = ie["imm"] & MASK32
                else:
                    alu_b = val_rt
                alu_result = alu_compute(ie["mnemonic"], val_rs, alu_b)
            next_ex_mem = {**ie, "alu_result": alu_result, "store_val": val_rt}

        # ---------- ID (+ hazard detection + branch resolution) ----------
        next_id_ex = None
        stall = False
        redirect_pc = None
        if self.IF_ID:
            d: Decoded = decode(self.IF_ID["word"])

            # Load-use hazard: instruction in EX (current ID_EX) is a load
            # whose destination is needed by the instruction now in ID.
            if (self.ID_EX and self.ID_EX["mem_read"]
                    and self.ID_EX["write_reg"] in (d.rs, d.rt)
                    and self.ID_EX["write_reg"] is not None):
                stall = True
                self.stall_count += 1
            else:
                # Branch comparisons happen in ID, one stage earlier than
                # normal EX forwarding reaches. The instruction 1-ahead is
                # still mid-EX this very cycle, so its result (next_ex_mem,
                # already computed above) must be forwarded same-cycle; the
                # instruction 2-ahead is covered by the (now one-cycle-old)
                # self.EX_MEM latch, and anything older is already visible
                # via regs.read() since WB committed earlier this tick.
                def _forward_id(reg_num, fallback):
                    if reg_num is None:
                        return fallback
                    if next_ex_mem and next_ex_mem["reg_write"] and next_ex_mem["write_reg"] == reg_num:
                        return next_ex_mem["alu_result"]
                    return self._forward(reg_num, fallback)

                rs_val = _forward_id(d.rs, self.regs.read(d.rs) if d.rs is not None else 0)
                rt_val = _forward_id(d.rt, self.regs.read(d.rt) if d.rt is not None else 0)

                if d.is_branch:
                    taken = (rs_val == rt_val) if d.mnemonic == "beq" else (rs_val != rt_val)
                    if taken:
                        redirect_pc = self.IF_ID["pc"] + 1 + d.imm
                        self.flush_count += 1
                elif d.is_jump:
                    redirect_pc = d.addr
                    self.flush_count += 1

                next_id_ex = {
                    "mnemonic": d.mnemonic, "pc": self.IF_ID["pc"],
                    "rs": d.rs, "rt": d.rt,
                    "write_reg": d.dest_reg, "imm": d.imm if d.imm is not None else 0,
                    "val_rs": rs_val, "val_rt": rt_val,
                    "reg_write": d.writes_reg, "mem_read": d.is_load, "mem_write": d.is_store,
                }

        # ---------- IF ----------
        fetched_pc = None
        if stall:
            next_if_id = self.IF_ID  # freeze: same instruction re-enters ID next cycle
        elif self.pc < len(self.imem):
            fetched_pc = self.pc
            next_if_id = {"word": self.imem[self.pc], "pc": self.pc}
            self.pc += 1
        else:
            next_if_id = None

        if redirect_pc is not None:
            next_if_id = None       # squash the instruction fetched this cycle
            fetched_pc = None
            self.pc = redirect_pc   # correct-path fetch starts next cycle

        # ---------- commit new latches ----------
        self._record_trace(stall, redirect_pc is not None, fetched_pc)
        self.IF_ID, self.ID_EX, self.EX_MEM, self.MEM_WB = (
            next_if_id, next_id_ex, next_ex_mem, next_mem_wb)

    def _forward(self, reg_num: int | None, fallback: int) -> int:
        """EX/MEM and MEM/WB forwarding paths (EX/MEM has priority since
        it holds the more recently produced value)."""
        if reg_num is None:
            return fallback
        if self.EX_MEM and self.EX_MEM["reg_write"] and self.EX_MEM["write_reg"] == reg_num:
            return self.EX_MEM["alu_result"]
        if self.MEM_WB and self.MEM_WB["reg_write"] and self.MEM_WB["write_reg"] == reg_num:
            return self.MEM_WB["write_data"]
        return fallback

    # ── introspection / diagram support ─────────────────────────
    def _record_trace(self, stalled: bool, flushed: bool, fetched_pc: int | None) -> None:
        def tag(latch, stage):
            if not latch:
                return None
            return {"stage": stage, "pc": latch.get("pc"), "mnemonic": latch.get("mnemonic")}

        id_info = None
        if self.IF_ID:
            id_info = {"pc": self.IF_ID["pc"], "mnemonic": decode(self.IF_ID["word"]).mnemonic}

        self.trace.append({
            "cycle": self.cycle,
            "IF": {"pc": fetched_pc} if fetched_pc is not None else None,
            "ID": id_info,
            "EX": tag(self.ID_EX, "EX"),
            "MEM": tag(self.EX_MEM, "MEM"),
            "WB": tag(self.MEM_WB, "WB"),
            "stalled": stalled,
            "flushed": flushed,
        })

    def print_diagram(self) -> None:
        """Print a classic instruction x cycle pipeline diagram."""
        by_pc: dict[int, dict[int, str]] = {}
        mnemonic_by_pc: dict[int, str] = {}
        for row in self.trace:
            for stage_name in ("IF", "ID", "EX", "MEM", "WB"):
                info = row[stage_name]
                if info and info.get("pc") is not None:
                    by_pc.setdefault(info["pc"], {})[row["cycle"]] = stage_name
                    if info.get("mnemonic"):
                        mnemonic_by_pc[info["pc"]] = info["mnemonic"]

        n_cycles = self.cycle
        header = "instr".ljust(16) + "".join(f"C{c:<4}" for c in range(1, n_cycles + 1))
        print(header)
        print("-" * len(header))
        for pc in sorted(by_pc):
            label = f"[{pc}] {mnemonic_by_pc.get(pc, '?')}".ljust(16)
            row = "".join(by_pc[pc].get(c, "").ljust(5) for c in range(1, n_cycles + 1))
            print(label + row)
        print(f"\nTotal cycles: {n_cycles}   Stalls: {self.stall_count}   "
              f"Branch/jump flushes: {self.flush_count}")

    def dump_registers(self) -> dict[str, int]:
        return self.regs.dump()
